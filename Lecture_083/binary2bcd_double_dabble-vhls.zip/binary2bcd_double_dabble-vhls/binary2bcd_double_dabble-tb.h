#ifndef __BINARY2BCD_TB_H__
#define __BINARY2BCD_TB_H__

#include "binary2bcd_double_dabble.h"

void binary2bcd_double_dabble(uint8 in_binary, uint16 *unpacked_bcd, uint8 *packed_bcd);
#endif //__BINARY2BCD_TB_H__
