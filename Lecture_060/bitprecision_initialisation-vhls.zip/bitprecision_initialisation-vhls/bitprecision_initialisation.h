#ifndef __ASSIGNMENT_H__
#define __ASSIGNMENT_H__

#include <ap_int.h>


#endif //__ASSIGNMENT_H__
