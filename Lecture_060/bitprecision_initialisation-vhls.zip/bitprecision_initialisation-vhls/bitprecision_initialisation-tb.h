#ifndef __ASSIGNMENT_TB_H__
#define __ASSIGNMENT_TB_H__
#include "bitprecision_initialisation.h"



void bitprecision_initialisation(
		ap_int<41> &a1,
		ap_int<41> &a2,
		ap_int<41> &a3,
		ap_int<41> &a4,

		ap_int<763> &b1,
		ap_int<763> &b2,
		ap_int<763> &b3);
#endif //__ASSIGNMENT_TB_H__
