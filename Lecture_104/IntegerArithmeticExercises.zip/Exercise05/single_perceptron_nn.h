#ifndef __SINGLE_PERCEPTRON_NN__
#define __SINGLE_PERCEPTRON_NN__

#include <ap_int.h>


#endif //__SINGLE_PERCEPTRON_NN__
