
#include "Overloading_example.h"

void overloading_example  (
    dtype A,      dtype  B,
    dtype  C,     dtype &D
) {

	D = A+B+C;
}



