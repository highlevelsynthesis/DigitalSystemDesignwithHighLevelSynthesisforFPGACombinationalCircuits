#ifndef __OVERLOADING_EXAMPLE_H__
#define __OVERLOADING_EXAMPLE_H__

#include <ap_int.h>

//typedef ap_int<23> dtype;
typedef int dtype;


#endif //__OVERLOADING_EXAMPLE_H__
