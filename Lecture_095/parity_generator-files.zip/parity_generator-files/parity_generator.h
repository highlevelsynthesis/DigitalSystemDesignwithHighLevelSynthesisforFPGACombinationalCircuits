#ifndef __PARITY_GENERATOR_H__
#define __PARITY_GENERATOR_H__

#include <ap_int.h>

const int W=16;



#endif //__PARITY_GENERATOR_H__
