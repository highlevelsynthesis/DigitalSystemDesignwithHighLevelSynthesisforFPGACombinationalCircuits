#ifndef __PARITY_GENERATOR_TB_H__
#define __PARITY_GENERATOR_TB_H__

#include "parity_generator.h"


bool parity_generator(ap_uint<W> a);



#endif //__PARITY_GENERATOR_TB_H__
