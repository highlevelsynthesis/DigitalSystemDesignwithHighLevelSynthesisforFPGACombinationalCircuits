/************************************************
Copyright (c) 2020, Mohammad Hosseinabady
All rights reserved.
Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software
without specific prior written permission.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. // Copyright (c) 2020, Mohammad Hosseinabady.
************************************************/

#include "datatype_exercise_01.h"


ap_uint<6> extract_opcode(ap_uint<32>  instruction) {

	return instruction(31, 26);
}

ap_uint<5> extract_rs(ap_uint<32>  instruction) {

	return instruction(25, 21);
}

ap_int<16> extract_imm(ap_uint<32>  instruction) {

	return instruction(15, 0);
}


void datatype_exercise_01(
		ap_uint<32>  instruction,
		ap_uint<6>  *opcode,
		ap_uint<5>  *rs,
		ap_uint<5>  *rd,
		ap_int<16>  *immidiate
		) {
#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma HLS INTERFACE ap_none port=instruction
#pragma HLS INTERFACE ap_none port=opcode
#pragma HLS INTERFACE ap_none port=rs
#pragma HLS INTERFACE ap_none port=rd
#pragma HLS INTERFACE ap_none port=immidiate

	*opcode    = extract_opcode(instruction);
	*rs        = extract_rs(instruction);
	*immidiate = extract_imm(instruction);
}
