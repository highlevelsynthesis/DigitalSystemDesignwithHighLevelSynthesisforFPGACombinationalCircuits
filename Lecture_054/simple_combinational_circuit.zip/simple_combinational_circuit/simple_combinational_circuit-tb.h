#ifndef __SIMPLE_COMBINATIONAL_CUIRCUIT_TB_H__
#define __SIMPLE_COMBINATIONAL_CUIRCUIT_TB_H__


void simple_combinational_circuit(
                   bool   a,
				   bool   b,
				   bool   c,
				   bool   *d
                );


#endif //__SIMPLE_COMBINATIONAL_CUIRCUIT_TB_H__
